/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.bean.CARRO;

/**
 *
 * @author Guilherme
 */
public class ObraDAO {
    
    public void create(CARRO o){
        
        Connection con = ConnectionFactory.getConenection();
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("INSERT INTO obra (isbn,titulo,autor,categoria) VALUES (?,?,?,?)");
            stmt.setString(1, o.getIsbn());
            stmt.setString(2, o.getTitulo());
            stmt.setString(3, o.getAutor());
            stmt.setString(4, o.getCategoria());

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null,"Salvo com Sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao Salvar:"+ex);
        }finally{
            ConnectionFactory.closeConnection(con,stmt);
        }
        
    }
    public void update(CARRO o){
        
        Connection con = ConnectionFactory.getConenection();
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("UPDATE obra SET isbn = ?, titulo = ?,autor = ?,categoria = ? WHERE id = ?");
            stmt.setString(1, o.getIsbn());
            stmt.setString(2, o.getTitulo());
            stmt.setString(3, o.getAutor());
            stmt.setString(4, o.getCategoria());
            stmt.setInt(5, o.getId());
            
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null,"Alterado com Sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao Atualizar:"+ex);
        }finally{
            ConnectionFactory.closeConnection(con,stmt);
        }
    }
    public void delete(CARRO o){
        
        Connection con = ConnectionFactory.getConenection();
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("DELETE FROM obra WHERE id = ?");
            
            stmt.setInt(1, o.getId());

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null,"Excluído com Sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao Excluir: Esta obra possui um ou mais exemplares cadastrados.");//FOI RETIRADO O +ex(exception) por ser muito grande
        }finally{
            ConnectionFactory.closeConnection(con,stmt);
        }
    }
    public List<CARRO> read (){
        
        Connection con = ConnectionFactory.getConenection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<CARRO> obras = new ArrayList<>();
        
        try {
            stmt = con.prepareStatement("SELECT * FROM obra");
            rs = stmt.executeQuery();
            
            while(rs.next()){
                
                CARRO obra = new CARRO();
                
                obra.setId(rs.getInt("id"));
                obra.setIsbn(rs.getString("isbn"));
                obra.setCategoria(rs.getString("categoria"));
                obra.setAutor(rs.getString("autor"));
                obra.setTitulo(rs.getString("titulo"));
                obras.add(obra);
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "NÃ£o foram encontrados dados!");
        }finally{
        
            ConnectionFactory.closeConnection(con, stmt, rs);
        
        }
        return obras;
        
    }
    /**
     *
     * @return
//     */
//    public List<OBRA> read(){
//        
//        Connection con = ConnectionFactory.getConenection();
//        PreparedStatement stmt = null;
//        
//        
//    }
//    
    
}

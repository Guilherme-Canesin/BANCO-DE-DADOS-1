/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;

/**
 *
 * @author Guilherme
 */
public class LOCACAO_POSSUI_ADICIONAIS {
    
    private int Id;
    private int ID_ADICIONAIS;

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public int getID_ADICIONAIS() {
        return ID_ADICIONAIS;
    }

    public void setID_ADICIONAIS(int ID_ADICIONAIS) {
        this.ID_ADICIONAIS = ID_ADICIONAIS;
    }
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;

/**
 *
 * @author Guilherme
 */
public class DEVOLUCAO {
    
    private int Id;
    private String CPF;
    private int Id_func;
    private String StatusCarro;

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public int getId_func() {
        return Id_func;
    }

    public void setId_func(int Id_func) {
        this.Id_func = Id_func;
    }

    public String getStatusCarro() {
        return StatusCarro;
    }

    public void setStatusCarro(String StatusCarro) {
        this.StatusCarro = StatusCarro;
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;

import java.util.Date;

/**
 *
 * @author Guilherme
 */
public class LOCACAO {
    
    private  int Id;
    private  String CPF_CLIENTE;
    private  String Id_funcionario;
    private  String Placa_Carro;
    private Date DATA_ALUGUEL;
    private Date DATA_LIMITE;
    private String ADICIONAIS; 

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getCPF_CLIENTE() {
        return CPF_CLIENTE;
    }

    public void setCPF_CLIENTE(String CPF_CLIENTE) {
        this.CPF_CLIENTE = CPF_CLIENTE;
    }

    public String getId_funcionario() {
        return Id_funcionario;
    }

    public void setId_funcionario(String Id_funcionario) {
        this.Id_funcionario = Id_funcionario;
    }

    public String getPlaca_Carro() {
        return Placa_Carro;
    }

    public void setPlaca_Carro(String Placa_Carro) {
        this.Placa_Carro = Placa_Carro;
    }

    public Date getDATA_ALUGUEL() {
        return DATA_ALUGUEL;
    }

    public void setDATA_ALUGUEL(Date DATA_ALUGUEL) {
        this.DATA_ALUGUEL = DATA_ALUGUEL;
    }

    public Date getDATA_LIMITE() {
        return DATA_LIMITE;
    }

    public void setDATA_LIMITE(Date DATA_LIMITE) {
        this.DATA_LIMITE = DATA_LIMITE;
    }

    public String getADICIONAIS() {
        return ADICIONAIS;
    }

    public void setADICIONAIS(String ADICIONAIS) {
        this.ADICIONAIS = ADICIONAIS;
    }

    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;

/**
 *
 * @author Guilherme
 */
public class CLIENTE {
    
    private String CPF;
    private String NOME;
    private String TELEFONE;
    private String ESTADO;
    private String CIDADE;
    private int  QUANT_RESERVA;

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getNOME() {
        return NOME;
    }

    public void setNOME(String NOME) {
        this.NOME = NOME;
    }

    public String getTELEFONE() {
        return TELEFONE;
    }

    public void setTELEFONE(String TELEFONE) {
        this.TELEFONE = TELEFONE;
    }

    public String getESTADO() {
        return ESTADO;
    }

    public void setESTADO(String ESTADO) {
        this.ESTADO = ESTADO;
    }

    public String getCIDADE() {
        return CIDADE;
    }

    public void setCIDADE(String CIDADE) {
        this.CIDADE = CIDADE;
    }

    public int getQUANT_RESERVA() {
        return QUANT_RESERVA;
    }

    public void setQUANT_RESERVA(int QUANT_RESERVA) {
        this.QUANT_RESERVA = QUANT_RESERVA;
    }
           
    
}
